#/bin/bash
echo "I like trains"
